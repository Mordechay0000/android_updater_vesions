#!/bin/bash

# Print a message to the console
echo "Starting the main.sh script..."

# Create a temporary file to demonstrate a command
TEMP_FILE="/data/local/tmp/test_file.txt"

# Create a test file and write a message to it
echo "This is a test file created by main.sh" > $TEMP_FILE

# Print the contents of the test file
cat $TEMP_FILE

# Indicate completion
echo "main.sh script completed."
